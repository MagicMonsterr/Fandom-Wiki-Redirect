const redirects = {
    "minecraft.fandom.com": {
        base: "https://minecraft.wiki",
        wiki: "/w/"
    },
    "warframe.fandom.com": {
        base: "https://wiki.warframe.com",
        wiki: "/w/"
    },
    "gta.fandom.com": {
        base: "https://gta.wiki",
        wiki: "/w/"
    },
    "jojo.fandom.com": {
        base: "https://jojowiki.com",
        wiki: "/"
    },
    "leagueoflegends.fandom.com": {
        base: "https://wiki.leagueoflegends.com",
        wiki: "/"
    },
    "overwatch.fandom.com": {
        base: "https://overwatch.weirdgloop.org",
        wiki: "/w/"
    },
    "fortnite.fandom.com": {
        base: "https://fortnite.weirdgloop.org",
        wiki: "/w/"
    },
    "terraria.fandom.com": { base: "https://terraria.wiki.gg" },
    "calamitymod.fandom.com": { base: "https://calamitymod.wiki.gg" },
    "thoriummod.fandom.com": { base: "https://thoriummod.wiki.gg" },
    "terrariamods.fandom.com": { base: "https://terrariamods.wiki.gg" },
    "fearandhunger.fandom.com": { base: "https://fearandhunger.wiki.gg" },
    "bindingofisaacrebirth.fandom.com": { base: "https://bindingofisaacrebirth.wiki.gg" },
    "pokemon.fandom.com": { base: "https://bulbapedia.bulbagarden.net" },
    "deadbydaylight.fandom.com": { base: "https://deadbydaylight.wiki.gg" },
    "teamfortress.fandom.com": { base: "https://wiki.teamfortress.com" }
}
const urlFilters = Object.keys(redirects).map(
    host => `*://${host}/*`
);
function redirect(requestDetails) {
    let currentUrl = new URL(requestDetails.url);

    let rule = redirects[currentUrl.hostname]
    let targetUrl = rule.base + currentUrl.pathname;
    console.log(targetUrl);
    if (typeof rule.wiki != 'undefined') {
        targetUrl = targetUrl.replace("/wiki/", rule.wiki)
    }

    console.log(`Redirecting: ${requestDetails.url} to ${targetUrl}`);
    if (requestDetails.url === targetUrl) {
      return;
    }
    return {
      redirectUrl: targetUrl,
    };
  }
  
browser.webRequest.onBeforeRequest.addListener(
    redirect,
    { urls: urlFilters },
    ["blocking"],
  );
